import serial
import numpy as np
from tensorflow.keras.models import load_model
from sklearn.preprocessing import MinMaxScaler

# Load the trained model
model_path = "lstm_model.h5"  # Path to the saved model
model = load_model(model_path)

# Configure the serial connection
serial_port = 'COM6'  # Replace with your port
baud_rate = 9600  # Match the baud rate with your device
timeout = 1  # Time in seconds to wait for data

# Initialize the MinMaxScaler (same configuration as used during training)
scaler = MinMaxScaler(feature_range=(0, 1))

# Simulated scaling values (replace with the actual feature range from training data)
scaler.fit([[300, 340, 400, 90], [350, 360, 450, 100]])  # Adjust range based on training data

try:
    # Initialize serial connection
    ser = serial.Serial(port=serial_port, baudrate=baud_rate, timeout=timeout)
    print(f"Connected to {serial_port} at {baud_rate} baud rate.")

    while True:
        if ser.in_waiting > 0:  # Check if data is available to read
            raw_data = ser.readline().decode('utf-8').strip()  # Read and decode the data
            print(f"Received: {raw_data}")

            # Process the data
            try:
                values = np.array([list(map(float, raw_data.split(',')))])  # Convert to float array
                if values.shape[1] == 4:  # Ensure there are 4 features
                    # Normalize the data
                    scaled_values = scaler.transform(values)

                    # Reshape the data for LSTM
                    reshaped_values = scaled_values.reshape(1, 4, 1)  # Batch size = 1, Time steps = 4, Features = 1

                    # Make prediction
                    prediction = model.predict(reshaped_values)

                    # Interpret the prediction
                    output = "Earthquake" if prediction[0][0] > 0.5 else "Normal"
                    print(f"Prediction: {output}")
                else:
                    print("Invalid input dimensions.")
            except Exception as e:
                print(f"Error processing data: {e}")
except serial.SerialException as e:
    print(f"Error: {e}")
except KeyboardInterrupt:
    print("Exiting program.")
finally:
    if 'ser' in locals() and ser.is_open:
        ser.close()
        print("Serial port closed.")
